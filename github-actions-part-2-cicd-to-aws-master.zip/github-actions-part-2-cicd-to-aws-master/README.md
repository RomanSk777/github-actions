# GitHub Actions deploy Flask to AWS Elastic Beanstalk




Status of Last Deployment:<br>
<img src="https://github.com/adv4000/github-actions-part-2-cicd-to-aws/workflows/CI-CD-Pipeline-to-AWS-ElasticBeastalk/badge.svg?branch=master"><br>


Copyleft by Denis Astahov ADV-IT 2019.
